package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class ProveedoresBSImpl implements IProveedoresBS{

	@Override
	public String crearProveedor(String nombre) {
		// Para poder probar las transacciones distribuidas, en algunos casos
		// la transaccion se tiene que hacer efectiva con commit
		// y en otros casos fallar para ordenar el rollback
		
		// Si el nombre del proveedor es Pepe falla la transaccion
		// Si es otro nombre se hace efectiva
		if ("Pepe".equals(nombre)) {
			throw new RuntimeException("Transaccion cancelada por nombre Pepe");
		}
		
		return "Proveedor " + nombre + " creado con exito";
	}

}

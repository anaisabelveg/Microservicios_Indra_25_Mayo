package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import es.indra.persistence.CarritosDAO;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class MicroServicioCarritoEurekaApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	public static void main(String[] args) {
		// El metodo main en Spring Boot esta dedicado exclusivamente a levantar el contexto de Spring
		// (arrancar el microservicio, crear el contenedor y hacer el ComponentScan para detectar todos los beans)
		// por lo tanto aqui no se escribe nada de codigo
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Este metodo se ejecuta automaticamente a continuacion del metodo main
		
		// Limpiar la coleccion de carritos
		//dao.deleteAll();
		
		// Mostrar todos los carritos
		dao.findAll().stream()
			.map(carrito -> carrito.getUsuario())
			.forEach(System.out::println);
		
	}

}

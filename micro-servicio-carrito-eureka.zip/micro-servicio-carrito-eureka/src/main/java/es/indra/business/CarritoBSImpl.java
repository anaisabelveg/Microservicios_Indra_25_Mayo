package es.indra.business;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private PedidosClienteFeign clienteFeign;
	
	@Autowired
	private CarritosDAO dao;

	@Override
	public Carrito crear(String usuario) {
		// Solo creamos el carrito si no existe otro para ese usuario
		Carrito carrito = consultar(usuario);
		
		if (carrito == null) {
			//carrito = new Carrito(usuario, null, 0);
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Pedido pedido = clienteFeign.crear(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importePedido = pedido.getProducto().getPrecio() * pedido.getCantidad();
		carrito.setImporte(importePedido + carrito.getImporte());
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		Pedido encontrado = contenido.stream()
								.filter(ped -> ped.getProducto().getID().equals(id))
								.findFirst()
								.get();
		contenido.remove(encontrado);
		
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		
		
		// Borro todos los pedidos que tienen ese id de producto
		// recoger en una coleccion todos los pedidos a eliminar
		// ir borrandolos
		/*
		List<Pedido> encontrados = contenido.stream()
				.filter(ped -> ped.getProducto().getID().equals(id))
				.collect(Collectors.toList());
		contenido.removeAll(encontrados);
		
		double importePedidos = encontrados.stream()
									.mapToDouble(ped -> ped.getProducto().getPrecio())
									.sum();
		carrito.setImporte(carrito.getImporte() - importePedidos);		
		*/
		
		return dao.save(carrito);
	}

}
















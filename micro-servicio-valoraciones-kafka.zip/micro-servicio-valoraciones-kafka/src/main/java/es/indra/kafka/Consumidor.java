package es.indra.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.KafkaListeners;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	// Si escucho de varios topics se puede configurar de 2 formas:
	//@KafkaListener(topics = {"topic1", "topic2", "topic3"})
	//@KafkaListeners({@KafkaListener(topics = "topic1"), @KafkaListener(topics = "topic2")})
	
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("***************************");
		System.out.println("Valoracion recibida: " + comentario);
		System.out.println("***************************");
	}

}

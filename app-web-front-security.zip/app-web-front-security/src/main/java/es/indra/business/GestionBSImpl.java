package es.indra.business;

import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import es.indra.models.Carrito;
import es.indra.models.Producto;

@Service
public class GestionBSImpl  implements IGestionBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Producto> obtenerTodos(String token) {
		String url = "http://localhost:8090/api/productos/listar";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setBearerAuth(token);
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headers);
		
		ResponseEntity<Producto[]> response = 
				restTemplate.exchange(url, HttpMethod.GET, request, Producto[].class);
		
		Producto[] productos = response.getBody();
			
		return Arrays.asList(productos);
	}

	@Override
	public Producto buscar(Long id) {
		String url = "http://localhost:8090/api/productos/buscar/{id}";
		return restTemplate.getForObject(url, Producto.class, id);
	}

	@Override
	public Carrito consultar(String usuario, String token) {
		String url = "http://localhost:8090/api/carrito/consultar/{usuario}";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setBearerAuth(token);
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headers);
		
		ResponseEntity<Carrito> response = 
				restTemplate.exchange(url, HttpMethod.GET, request, Carrito.class);
		
		return response.getBody();
	}

	@Override
	public Carrito crear(String usuario) {
		String url = "http://localhost:8090/api/carrito/crear/{usuario}";	
		return restTemplate.postForObject(url, null, Carrito.class, usuario);
	}

	@Override
	public void agregar(Long id, int cantidad, String usuario) {
		String url = "http://localhost:8090/api/carrito/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}";
		restTemplate.put(url, null, id, cantidad, usuario);
	}

	@Override
	public void eliminar(Long id, String usuario) {
		String url = "http://localhost:8090/api/carrito/eliminar/id/{id}/usuario/{usuario}";
		restTemplate.delete(url, id, usuario);
	}

}

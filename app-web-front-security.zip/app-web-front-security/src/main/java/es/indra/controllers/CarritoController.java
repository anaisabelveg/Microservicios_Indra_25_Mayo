package es.indra.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.business.IGestionBS;
import es.indra.models.Carrito;

@Controller
@RequestMapping("/")
public class CarritoController {
	
	@Autowired
	private IGestionBS bs;
	
	@PostMapping(value = "comprar")
	public String addPedido(long id, int cantidad, HttpServletRequest request, HttpSession session) {
		
		String token = (String) session.getAttribute("JWT");
		
		String usuario = null;
		boolean logado = false;
		
		// Recuperar las cookies y comprobar si tenemos el nombre del usuario
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ("nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
				logado = true;
				break;
			}
		}
		
		// Si el usuario no esta logado le enviamos al formulario de login
		if (!logado) return "formLogin";
		
		// Si el usuario si esta logado agregamos el pedido al carrito
		bs.agregar(id, cantidad, usuario);
		Carrito carrito = bs.consultar(usuario, token);
		request.setAttribute("carrito", carrito);
		return "mostrarCarrito";
	}
	
	@GetMapping(value = "sacar")
	public String sacarPedido(long id, String usuario, HttpServletRequest request, HttpSession session) {
		
		String token = (String) session.getAttribute("JWT");
		
		bs.eliminar(id, usuario);
		Carrito carrito = bs.consultar(usuario, token);
		request.setAttribute("carrito", carrito);
		return "mostrarCarrito";
	}

}

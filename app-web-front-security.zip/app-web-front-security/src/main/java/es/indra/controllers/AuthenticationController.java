package es.indra.controllers;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
@RequestMapping({"/"})
public class AuthenticationController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@RequestMapping(method = RequestMethod.GET, value = "")
	public String inicio() {
		return "formAutenticacion";
	}
	
	@PostMapping("/oauth")
	public String procesar(@RequestParam String username, 
			@RequestParam String password, HttpSession session) {
		
		String url = "http://localhost:8090/api/security/oauth/token";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth("webapp", "12345");
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
		body.add("username", username);
		body.add("password", password);
		body.add("grant_type", "password");
		
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(body,headers);
		
		ResponseEntity<Map> response = 
				restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
		
		Map<String, Object> tokenMap = response.getBody();
		
		String token = tokenMap.get("access_token").toString();
		
		// Guardamos el token en la sesion
		session.setAttribute("JWT", token);
		
		System.out.println("*************************");
		System.out.println(token);
		System.out.println("*************************");
		
		
		return "index";
	}

}














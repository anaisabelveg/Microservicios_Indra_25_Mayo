<%@page import="es.indra.models.Producto"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h1>Nuestro catalogo de productos</h1>
		
		<% List<Producto> lista = (List<Producto>) request.getAttribute("lista"); %>
		
		<table border="1" align="center">
			<tr>
				<th>ID</th>
				<th>DESCRIPCION</th>
				<th>PRECIO</th>
				<th>CANTIDAD</th>
				<th>COMPRAR</th>
			</tr>
			
			<% for(Producto p: lista){ %>
				<tr>
					<td> <%= p.getID() %> </td>
					<td> <%= p.getDescripcion() %> </td>
					<td> <%= p.getPrecio() %> </td>
					
					<form action="comprar" method="post">
						<input type="hidden" name="id" value="<%= p.getID() %>" />
						<td> <input type="number" name="cantidad" /> </td>
						<td> <input type="submit" value="Agregar al carrito" /> </td>
					</form>
					 
				</tr>
			<% } %>
		
		</table>
	</body>
</html>
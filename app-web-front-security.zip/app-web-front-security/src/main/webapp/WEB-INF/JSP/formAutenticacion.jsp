<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h2>Autenticacion de usuario</h2>
		
		<form action="oauth" method="post">
			<label>Username:</label>
			<input type="text" name="username" /> <br/>
			
			<label>Password:</label>
			<input type="password" name="password" /> <br/>
			
			<input type="submit" value="Logarme" />
			
		</form>
	</body>
</html>
package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import es.indra.models.Producto;

// Al utilizar Servicio de Descubrimiento con Eureka, ya no se necesita la ip:puerto del servicio-productos
//@FeignClient(url = "localhost:8001", name = "servicio-productos")
@FeignClient(name = "servicio-productos")
public interface ProductosClienteFeign {

	// Mapear a donde vamos a emitir la peticion
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id);
	
	@PostMapping("/nuevo/descripcion/{descripcion}/precio/{precio}")
	public Producto nuevo(@PathVariable String descripcion, @PathVariable double precio);
	
	@DeleteMapping("/eliminar/{id}")
	public String eliminar(@PathVariable Long id);
}

package es.indra.business;

import es.indra.models.Pedido;

public interface IPedidosBS {
	
	public Pedido crearPedido(Long id, int cantidad);
	
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor);

}

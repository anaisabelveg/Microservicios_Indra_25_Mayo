package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que con try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/76567886/cantidad/100
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorCodigo(FeignException ex){
		System.out.println("Error de validacion: " + ex.getMessage());
		return new ResponseEntity<String>("ID de producto no valido", HttpStatus.BAD_REQUEST);
	}
	
	// http://localhost:8002/crear/kyhkjhgkhgvhk/cantidad/100
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> errorTexto(Exception ex){
		System.out.println("Error de formato: " + ex.getMessage());
		return new ResponseEntity<String>("ID de producto debe ser numerico", HttpStatus.BAD_REQUEST);
	}

}

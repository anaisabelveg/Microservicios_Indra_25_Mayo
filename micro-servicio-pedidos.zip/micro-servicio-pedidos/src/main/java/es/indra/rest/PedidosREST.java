package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;

@RestController
//@RequestMapping("/api")
public class PedidosREST {
	
	/*
	 * Como ahora tenemos 2 implementaciones de IPedidosBS, Spring da un error para que elijamos una de ellas:
	 * 			- @Autowired @Primary
	 * */
	
	@Autowired  // No permite especificar el bean que quiero inyectar
	// 1ª solucion es utilizar @Primary
	// 2ª solucion es utilizar @Qualifier("id del bean")
	@Qualifier("pedidosBSFeign")   // nombre de la clase pero la primera letra en minusculas
	private IPedidosBS bs;
	
	// http://localhost:8002/api/crear/4/cantidad/25   url si descomento @RequestMapping
	// http://localhost:8002/crear/4/cantidad/25
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}

}

package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class JavaConfig {
	
	@Bean   // Convierte un objeto Java en un bean de Spring
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}

package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
//@Primary
public class PedidosBSRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Con el id recibido buscamos el producto
		
		// Al utilizar Servicio de Descubrimiento con Eureka, ya no se necesita la ip:puerto del servicio-productos
//		Producto producto = restTemplate.getForObject(
//				"http://localhost:8001/buscar/{codigo}", Producto.class, id);
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido y retornarlo
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
